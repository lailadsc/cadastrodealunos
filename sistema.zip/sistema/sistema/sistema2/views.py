from django.shortcuts import render
from django.http import HttpResponse
from .forms import Cadastrarform
from . models import criarAluno
# Create your views here.

def index(request):
    return render(request, 'cadastroalunos/index.html' )

def aluno(request):
    aluno = criarAluno.objects.all()
    return render(request, 'cadastroalunos/alunos.html', {'alunos':alunos})

def cadastrar_aluno (request):
    form = Cadastrarform(request.POST)
    if form.is_valid():
        cadastraraluno = form.save()
        cadastraaluno.save()
        form = Cadastrarform()
    else:
       form = Cadastrarform(request.POST)    
    return render(request, 'cadastroalunos/cadastraraluno.html', {'form':form})