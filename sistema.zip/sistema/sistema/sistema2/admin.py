from django.contrib import admin
from django.db.models.fields import CharField

# Register your models here.

from .models import criarAluno

admin.site.register(criarAluno)