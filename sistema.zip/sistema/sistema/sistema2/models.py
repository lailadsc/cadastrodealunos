from django.db import models
from django.db.models.aggregates import Max
from django.db.models.fields import CharField
# Create your models here.

class criarAluno(models.Model):
    Nome = models.CharField(max_length=200)
    CPF = models.IntegerField(unique=True)
    Data_Nascimento = models.CharField(max_length=10)
    Logradouro = models.CharField(max_length=100)
    Numero = models.IntegerField()
    Complemento = models.CharField(max_length=200, blank=True, null=True)
    Bairro = models.CharField(max_length=50)
    Cidade = models.CharField(max_length=100)
    Estado = models.CharField(max_length=100)
    CEP = models.IntegerField()

    def __str__(self):

        return self.Nome
