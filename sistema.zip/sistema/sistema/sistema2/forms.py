from django import forms 
from .models import criarAluno

class Cadastrarform(forms.ModelForm):
    class Meta:
        model = criarAluno
        fields ='__all__'
